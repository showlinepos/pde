## Module <accounting_pdf_reports>

#### 26.06.2022
#### Version 14.0.5.2.0
##### IMP
- journal entry report total decimal

#### 11.03.2022
#### Version 14.0.5.1.0
##### IMP
- dynamic report link

#### 28.02.2022
#### Version 14.0.5.0.0
##### IMP
- code refactoring

#### 01.02.2022
#### Version 14.0.4.8.0
##### FIX
- New translation

#### 13.07.2021
#### Version 14.0.4.7.0
##### IMP
- Menu Re-arrangement
